<script language="php">
  session_name("gmhome_webaccess_session");
  session_register("SESSION_DATA", "SESSION_USER");
</script>
