<script language="php">
if( $HTTP_HOST == "" ) $HTTP_HOST = "localhost";
$SYSHOME_HTTP_ROOT=$HTTP_HOST;
$EXIT_PAGE="javascript:window.close();";
$INIT_PAGE="http://".$SYSHOME_HTTP_ROOT."/fotos/home.php";
$LOGIN_PAGE="https://".$SYSHOME_HTTP_ROOT."/fotos/login/index.php";
$LOGIN_PAGE_INTRANET="http://".$SYSHOME_HTTP_ROOT."/fotos/login/index.php";
$SESSION_KEY="8660281B6051D071";
$ADMIN_USER="admin";
$ZONA_SEGURA[0] = "192.168.0.0";
$dbserver="bootsie.witchblade";
$dbuser="home";
$dbpass="home";
$homeserver="bootsie.witchblade";
$homeport="5533";
</script>
