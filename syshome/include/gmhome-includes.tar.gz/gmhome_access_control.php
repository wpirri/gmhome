<script language="php">
  header("Cache-Control: no-cache; must-revalidate;");
  require('gmhome_session.php');

  function acceso_local($IP)
  {
    require('gmhome_config.php');

    list($a1, $b1, $c1, $d1) = sscanf($IP,"%d.%d.%d.%d");
    for( $i = 0; isset($ZONA_SEGURA[$i]); $i++)
    {
      list($a2, $b2, $c2, $d2) = sscanf($ZONA_SEGURA[$i], "%d.%d.%d.%d");
      if(  (( $a2 == 0 ) || ($a2 == $a1)) &&
           (( $b2 == 0 ) || ($b2 == $b1)) &&
           (( $c2 == 0 ) || ($c2 == $c1)) &&
           (( $d2 == 0 ) || ($d2 == $d1))  ) return true;
    }
    return false;
  }

  function acceso_valido($string_acceso, $user, $addr, $browser)
  {
    require('gmhome_config.php');

    $cmd = "/usr/local/bin/gmcrypt -d -k $SESSION_KEY $string_acceso";
    exec($cmd, $output);
    if(count($output) < 1)
    {
      return false;
    }
    else
    {
      $str_temp = $output[0];
    }
    $str_temp_2 = "";
    for($i = 0; $i < strlen($str_temp); $i+=2)
    {
      $str_temp_2 .= chr(hexdec(substr($str_temp,$i,2)));
    }
    $data = split("@-@", $str_temp_2);
    // tiempo de sesion en segundos
    $t = time() - 600;

    if( $data[0] == "0"       &&
        $data[2] == $user     &&
        $data[4] == $addr     &&
        $data[6] == $browser  &&
        $data[8] > $t         &&
        $data[10] == "9"       )
    {
      // Session OK
      return true;
    }
    return false;
  }

  function string_acceso($user, $addr, $browser)
  {
    require('gmhome_config.php');

    $r1 = rand(0,9999);
    $r2 = rand(0,9999);
    $r3 = rand(0,9999);
    $r4 = rand(0,9999);
    $r5 = rand(0,9999);
    $t = time();
    $str_temp = "0@-@".$r1."@-@".$user."@-@".$r2."@-@".$addr."@-@".$r3."@-@".$browser."@-@".$r4."@-@".$t."@-@".$r5."@-@9@-@";
    $str_temp = bin2hex($str_temp);
    while( (strlen( $str_temp ) % 16) != 0 ) $str_temp = $str_temp."F";
    $str_temp = strtoupper($str_temp);
    $cmd = "/usr/local/bin/gmcrypt -e -k $SESSION_KEY $str_temp";
    exec($cmd, $output);
    if(count($output) < 1)
    {
      return false;
    }
    else
    {
      $str_temp = $output[0];
    }
    return $str_temp;
  }

  function control_acceso($SESSION_DATA, $SESSION_USER, $REMOTE_ADDR, $HTTP_USER_AGENT, $PRODUCTO)
  {
    require('gmhome_config.php');

    if( acceso_local($REMOTE_ADDR) ) return true;

    if( !acceso_valido($SESSION_DATA, $SESSION_USER, $REMOTE_ADDR, $HTTP_USER_AGENT) )
    {
      ?> 
      <script language="JavaScript">
        setTimeout('window.location.replace("<? echo $EXIT_PAGE; ?>")', 1);
      </script>
      <?
      return false;
    }
    if( !control_permisos($SESSION_USER, $PRODUCTO, $REMOTE_ADDR))
    {
      ?> 
      <script language="JavaScript">
        alert('Acceso no permitido');
        window.close();
      </script>
      <?
      return false;
    }
    return true;
  }

  function control_permisos($user, $producto, $ip)
  {
    require('gmhome_config.php');

    if( acceso_local($ip) ) return true;

    if($user == $ADMIN_USER) return true;

    $db = new PPgSqlDB;
    if($db->Open($dbserver, "home", $dbuser, $dbpass))
    {
      if($db->Select("producto",                                     // SELECT
          "product_access",                                          // FROM
          "usuario = '".$user."' AND producto = '".$producto."'",    // WHERE
          "",                                                        // ORDER BY
          ""))                                                       // GROUP BY
      {
        return true;
      }
    }
    return false;
  }

</script>
