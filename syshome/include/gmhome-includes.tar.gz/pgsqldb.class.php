<script language="php">

/*
	Clase PPgSqlDB
	Acceso a Bases de datos Postgre
	WGP - 2001
*/

class PPgSqlDB
{
	var $m_dbid;
	var $m_qryid;
	var $qryindex;
	var $qrydata;
	var $qryrows;
	var $sql_query;

	function IsOpen()
	{
		if( $this->m_dbid != false ) return true;
		else return false;
	}

	function Open($dbhost, $dbname, $dbuser, $dbpassword)
	{
		$strConnect = "";
		if(strlen($dbhost))
		{
			$strConnect .= "host=$dbhost ";
		}
		else 
		{
			$strConnect .= "host=localhost ";
		}
		if(strlen($dbname))
		{
			$strConnect .= "dbname=$dbname ";
		}
		if(strlen($dbuser))
		{
			$strConnect .= "user=$dbuser ";
		}
		if(strlen($dbpassword))
		{
			$strConnect .= "password=$dbpassword ";
		}

		if(($this->m_dbid = pg_connect($strConnect)) == 0)
		{
			return false;
		}
		$this->qryrows = 0;
		return true;
	}

	function Close()
	{
		pg_close($this->m_dbid);
		return true;
	}

	function Begin()
	{
		if(pg_exec($this->m_dbid, "BEGIN") <= 0)
		{
			return false;
		}
		return false;
	}
	
	function End()
	{
		if(pg_exec($this->m_dbid, "END") <= 0)
		{
			return false;
		}
		return false;
	}

	function Commit()
	{
		if(pg_exec($this->m_dbid, "COMMIT") <= 0)
		{
			return false;
		}
		return false;
	}

	function Rollback()
	{
		if(pg_exec($this->m_dbid, "ROLLBACK") <= 0)
		{
			return false;
		}
		return false;
	}

	function Select($data, $from, $where, $order, $group)
	{
		$sql_query = "SELECT ";

		if(strlen($data) > 0) $sql_query .= "$data ";
		else $sql_query .= "* ";

		if(strlen($from) > 0) $sql_query .= "FROM $from ";

		if(strlen($where) > 0) $sql_query .= "WHERE $where ";

		if(strlen($order) > 0) $sql_query .= "ORDER BY $order ";
		
		if(strlen($group) > 0) $sql_query .= "GROUP BY $group";
		
		//echo "<br>$sql_query<br>";

		$this->qryindex = 0;
		if(($this->m_qryid = pg_exec($this->m_dbid, $sql_query)) <= 0)
		{
			return false;
		}
		if(($this->qryrows = pg_numrows($this->m_qryid)) <= 0)
		{
			return false;
		}
		if(!($this->qrydata = pg_fetch_row($this->m_qryid, $this->qryindex++)))
		{
			return false;
		}
		return true;
	}
	
	function SelectData($row)
	{
		// las columnas se numeran desde 0
		if(is_string($row)) return $this->qrydata[$row];
		else return $this->qrydata[($row - 1)];
	}
	
	function SelectNext()
	{
		if($this->qryindex >= $this->qryrows)
		{
			return false;
		}
		if(!($this->qrydata = pg_fetch_row($this->m_qryid, $this->qryindex++)))
		{
			return false;
		}
		return true;
	}
	
	function SelectEnd()
	{
		$this->qryindex = 0;
		$this->m_qryid = 0;
		return true;
	}
	
	function Update($from, $data, $where)
	{
		$sql_query = "UPDATE $from SET $data";
		if(strlen($where))
		{
			$sql_query .= " WHERE $where";
		}

		//echo "<br>$sql_query<br>";

		if( !($result = pg_exec($this->m_dbid, $sql_query)))
		{
			return false;
		}
		return true;
	}

	function Insert($from, $data, $value)
	{
		if(strlen($data))
		{
			$sql_query = "INSERT INTO $from ($data)";
		}
		else
		{
			$sql_query = "INSERT INTO $from";
		}
		$sql_query .= " VALUES ($value)";

		//echo "$sql_query <br>";

		if(pg_exec($this->m_dbid, $sql_query) <= 0)
		{
			return false;
		}
		return true;
	}
	
	function Delete($from, $where)
	{
		$sql_query = "DELETE FROM $from";
		if(strlen($where))
		{
			$sql_query .= " WHERE $where";
		}
		if(pg_exec($this->m_dbid, $sql_query) <= 0)
		{
			return false;
		}
		return true;
	}

	function LastError()
	{
		return pg_last_error($this->m_dbid);
	}

	function LastId()
	{
		$this->Select("lastval()", "", "", "", "");
		return $this->SelectData(1);
	}
}

</script>
