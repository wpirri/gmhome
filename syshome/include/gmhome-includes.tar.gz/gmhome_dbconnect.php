<script language="php">
/*  require('odbcdb.class.php');
  $db = new POdbcDB;
  $dbserver = "";
  $dbuser = "";
  $dbpass = "";

  require('mysqldb.class.php');
*/

  require('pgsqldb.class.php');
/*
  $db = new PPgSqlDB;
  $dbserver = "";
  $dbuser = "";
  $dbpass = "";
*/
</script>
