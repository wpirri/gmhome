<script language="php">

/*
	Clase PMySqlDB
	Acceso a Bases de datos MySQL
	WGP - 2001
*/

class PMySqlDB
{
	var $m_dbid = false;
	var $m_qryid;
	var $qrydata;

	function IsOpen()
	{
		if( $this->m_dbid != false ) return true;
		else return false;
	}

	function Open($dbhost, $dbname, $dbuser, $dbpassword)
	{
		if(($this->m_dbid = mysql_connect($dbhost, $dbuser, $dbpassword)) == 0)
		{
			return false;
		}
		if(mysql_select_db($dbname, $this->m_dbid) == 0)
		{
			mysql_close($this->m_dbid);
			return false;
		}
		return true;
	}

	function Close()
	{
		mysql_close($this->m_dbid);
		return true;
	}
	
	function Select($data, $from, $where, $order, $group)
	{
		$sql_query = "SELECT ";

		if(strlen($data) > 0) $sql_query .= "$data ";
		else $sql_query .= "* ";

		if(strlen($from) > 0) $sql_query .= "FROM $from ";
		//else return false;

		if(strlen($where) > 0) $sql_query .= "WHERE $where ";

		if(strlen($group) > 0) $sql_query .= "GROUP BY $group ";
		
		if(strlen($order) > 0) $sql_query .= "ORDER BY $order ";
		
		//echo "<br>$sql_query<br>";

		if(($this->m_qryid = mysql_query($sql_query, $this->m_dbid)) <= 0)
		{
			return false;
		}
		if(!($this->qrydata = mysql_fetch_row($this->m_qryid)))
		{
			return false;
		}
		return true;
	}
	
	function SelectData($row)
	{
		// en mysql las columnas se numeran desde 0
		if(is_string($row)) return $this->qrydata[$row];
		else return $this->qrydata[($row - 1)];
	}
	
	function SelectNext()
	{
		if(!($this->qrydata = mysql_fetch_row($this->m_qryid)))
		{
			return false;
		}
		return true;
	}
	
	function SelectEnd()
	{
		$this->m_qryid = 0;
		return true;
	}
	
	function Update($from, $data, $where)
	{
		$sql_query = "UPDATE $from SET $data";
		if(strlen($where))
		{
			$sql_query .= " WHERE $where";
		}
		if(mysql_query($sql_query, $this->m_dbid) <= 0)
		{
			return false;
		}
		return true;
	}

	function Insert($from, $data, $value)
	{
		if(strlen($data))
		{
			$sql_query = "INSERT INTO $from ($data)";
		}
		else
		{
			$sql_query = "INSERT INTO $from";
		}
		$sql_query .= " VALUES ($value)";

		//echo "$sql_query <br>";

		if(mysql_query($sql_query, $this->m_dbid) <= 0)
		{
			return false;
		}
		return true;
	}
	
	function Delete($from, $where)
	{
		$sql_query = "DELETE FROM $from";
		if(strlen($where))
		{
			$sql_query .= " WHERE $where";
		}
		//echo "$sql_query <br>";
		if(mysql_query($sql_query, $this->m_dbid) <= 0)
		{
			return false;
		}
		return true;
	}

	function LastId()
	{
		return mysql_insert_id($this->m_dbid);
	}
}

</script>
